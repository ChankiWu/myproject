# coding = utf-8

from .forms import *
from .models import *
from django.shortcuts import render, render_to_response
from django.contrib.auth.decorators import login_required
from django.contrib import auth
from django.contrib.auth import authenticate, login, logout
from django.views.decorators.csrf import csrf_protect
from django.http import HttpResponseRedirect
from django.template import RequestContext
from django.db import transaction

# Create your views here.
# @login_required(login_url='/login/')
def home(request):
    if request.user.is_authenticated():
        userobject = Touruser.objects.all().filter(user = request.user.id)
        # print request.user.id
        return render(request, 'home.html' , {'currentuser':userobject})
    else:
        return render(request, 'home.html' , {})


# @csrf_protect
@transaction.atomic
def loginpage(request):
    if request.user.is_authenticated():
    	return HttpResponseRedirect('../home')
    elif request.method == 'POST':
        username = request.POST.get('username')
       	password = request.POST.get('password')
        user = auth.authenticate(username=username, password=password)
        if user is not None and user.is_active:
            auth.login(request,user)
            # User seesion will expiry after a day, which is 86400 sec
            request.session.set_expiry(86400)
            return HttpResponseRedirect('../home')
        else:
            return render(request, 'login.html', {})
    return render(request, 'login.html', {})

@csrf_protect
@transaction.atomic
def registerpage(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = User.objects.create_user(
            username=form.cleaned_data['username'],
            password=form.cleaned_data['password1'],
            email=form.cleaned_data['email']
            )
            Touruser.objects.create(user = user,
            utag=form.cleaned_data['utag'], usign=form.cleaned_data['usign'],
            )
            print user.date_joined
            return HttpResponseRedirect('../home/')
    else:
        form = RegistrationForm()
    variables = RequestContext(request, {
    'form': form
    })

    return render_to_response(
    'register.html',
    variables,
    )

@login_required(login_url='../login/')
def logoutfunction(request):
    auth.logout(request)
    return HttpResponseRedirect('../login/')

# @login_required(login_url='../login/')
def destination(request,destid):
    destresult = Tourdest.objects.all().filter(did=destid)
    tripresult = Tourtrip.objects.all().filter(tdest=destid)
    return render(request, 'destination.html', {'destresult':destresult,'tripresult':tripresult})


# @login_required(login_url='../login/')
def forum(request):
    if request.user.is_authenticated():
        userobject = Touruser.objects.all().filter(user = request.user.id)
        # print request.user.id
        return render(request, 'forum.html' , {'currentuser':userobject})
    return render(request, 'forum.html' , {})

# @login_required(login_url='../login/')
def triplist(request):
    if request.user.is_authenticated():
        userobject = Touruser.objects.all().filter(user = request.user.id)
        # print request.user.id
        return render(request, 'triplist.html' , {'currentuser':userobject})
    return render(request, 'triplist.html' , {})

# @login_required(login_url='../login/')
def trip(request,tripid):
    tripresult = Tourtrip.objects.all()
    thistrip = Tourtrip.objects.all().filter(tid=tripid)
    content = thistrip[0].ttrip
    if request.user.is_authenticated():
        userobject = Touruser.objects.all().filter(user = request.user.id)
        return render(request, 'trip.html', {'currentuser':userobject, 'thistrip':thistrip,'content':content})
    return render(request, 'trip.html', {'thistrip':thistrip,'content':content})

# @login_required(login_url='../login/')
def journal(request,jjid):
    if request.user.is_authenticated():
        userobject = Touruser.objects.all().filter(user = request.user.id)
        journalresult = Tourjournal.objects.all()
        thisjournal = Tourjournal.objects.all().filter(jid=jjid)
        # print request.user.id
        return render(request, 'journal.html' , {'currentuser':userobject,'thisjournal':thisjournal})
    journalresult = Tourjournal.objects.all()
    thisjournal = Tourjournal.objects.all().filter(jid=jjid)
    return render(request, 'journal.html', {'thisjournal':thisjournal})

@login_required(login_url='../login/')
def editjournal(request):
    return render(request, 'journaledit.html' , {})

@login_required(login_url='../login/')
def addjournal(request):
    # getinfo = Tourjournal.objects.all()

    # getuser = Touruser.objects.all()
    # print(getuser[0].uid)

    if request.is_ajax():
        if request.method == 'POST':
            print ('come to ajax...')
            print (request.user.id)
            #  print ("come into ajax! " + request.body)
            # newrecord = Tourjournal.objects.create(jname='Test', jcontent=request.body, juser_id=request.user.id)

            # we use this way to solve the problem of foreign key instead of Tourjournal.objects.create()
            d1 = Touruser.objects.get(user=request.user.id)
            u1 = Tourjournal(jname='Test', jcontent=request.body, juser=d1)
            # save in database
            u1.save()

    return HttpResponseRedirect('../personal')
    # return HttpResponse("OK")

@login_required(login_url='../login/')
def personal(request):
    if request.user.is_authenticated():
        userobject = Touruser.objects.all().filter(user = request.user.id)
        return render(request, 'user.html' , {'currentuser':userobject})
    return render(request, 'user.html', {})

@login_required(login_url='../login/')
def profile(request):
    if request.user.is_authenticated():
        userobject = Touruser.objects.all().filter(user = request.user.id)
        return render(request, 'userprofile.html' , {'currentuser':userobject})
    return render(request, 'userprofile.html', {})

@login_required(login_url='../login/')
def editprofile(request):
    if request.user.is_authenticated():
        userobject = Touruser.objects.all().filter(user = request.user.id)
        return render(request, 'userprofileedit.html' , {'currentuser':userobject})
    return render(request, 'userprofileedit.html', {})
