from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^index/$', views.index, name='index'),
    url(r'^journalsadd/$', views.Tourjournal_add, name='Tourjournal_add'),
]
