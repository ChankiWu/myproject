# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from __future__ import unicode_literals

from django.db import models


class Tourdest(models.Model):
    did = models.AutoField(primary_key=True)
    dname = models.CharField(max_length=63)
    dinfo = models.CharField(max_length=255)
    drealweather = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tourdest'


class Tourjournal(models.Model):
    jid = models.AutoField(primary_key=True)
    jname = models.CharField(max_length=63)
    jcontent = models.TextField()
    juser = models.ForeignKey('Touruser', models.DO_NOTHING, db_column='juser')
    jtag = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tourjournal'


class Tourspot(models.Model):
    sid = models.AutoField(primary_key=True)
    sname = models.CharField(max_length=63)
    scover = models.CharField(max_length=255)
    sinfo = models.TextField()
    sdest = models.ForeignKey(Tourdest, models.DO_NOTHING, db_column='sdest')

    class Meta:
        managed = False
        db_table = 'tourspot'


class Tourtrip(models.Model):
    tid = models.AutoField(primary_key=True)
    tcover = models.CharField(max_length=255)
    tdescrip = models.CharField(max_length=255)
    tdays = models.IntegerField()
    tpeople = models.CharField(max_length=63)
    ttrip = models.TextField()
    tdest = models.ForeignKey(Tourdest, models.DO_NOTHING, db_column='tdest')
    tspot = models.ForeignKey(Tourspot, models.DO_NOTHING, db_column='tspot')

    class Meta:
        managed = False
        db_table = 'tourtrip'


class Touruser(models.Model):
    uid = models.AutoField(primary_key=True)
    uname = models.CharField(max_length=45)
    uico = models.CharField(max_length=255)
    usign = models.CharField(max_length=31, blank=True, null=True)
    ulocation = models.CharField(max_length=63, blank=True, null=True)
    ujointime = models.CharField(max_length=15)
    utag = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'touruser'
