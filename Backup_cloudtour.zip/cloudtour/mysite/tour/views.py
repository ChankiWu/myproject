# coding=utf-8

from django.shortcuts import render
from .models import Tourjournal
from django.http import HttpResponse, HttpResponseRedirect

# Create your views here.

def index(request):
    # 把数据库中Tourjournal的部分全部拿下来
    posts = Tourjournal.objects.all()
    return render(request, 'index.html', {'posts': posts})


def Tourjournal_add(request):
    # 把前台form表单提交的游记内容入库
    jtext = request.POST.get('jhtml')
    print(jtext)
    # currentuser = request.user
    # print currentuser.uid

    newrecord = Tourjournal.objects.create(jid=1, jname='wqc', jcontent=jtext, juser=1)

    return HttpResponseRedirect('../index')