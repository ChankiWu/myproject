/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50711
Source Host           : localhost:3306
Source Database       : cloudtour

Target Server Type    : MYSQL
Target Server Version : 50711
File Encoding         : 65001

Date: 2016-12-21 22:20:43
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tourdest
-- ----------------------------
DROP TABLE IF EXISTS `tourdest`;
CREATE TABLE `tourdest` (
  `did` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dname` varchar(63) NOT NULL,
  `dinfo` varchar(255) NOT NULL,
  `drealweather` text,
  PRIMARY KEY (`did`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for tourjournal
-- ----------------------------
DROP TABLE IF EXISTS `tourjournal`;
CREATE TABLE `tourjournal` (
  `jid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jname` varchar(63) NOT NULL,
  `jcontent` mediumtext NOT NULL,
  `juser` int(10) unsigned NOT NULL,
  `jtag` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`jid`),
  KEY `fk_journal_user` (`juser`),
  CONSTRAINT `fk_journal_user` FOREIGN KEY (`juser`) REFERENCES `touruser` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tourspot
-- ----------------------------
DROP TABLE IF EXISTS `tourspot`;
CREATE TABLE `tourspot` (
  `sid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sname` varchar(63) NOT NULL,
  `scover` varchar(255) NOT NULL,
  `sinfo` mediumtext NOT NULL,
  `sdest` int(10) unsigned NOT NULL,
  PRIMARY KEY (`sid`),
  KEY `fk_spot_dest` (`sdest`),
  CONSTRAINT `fk_spot_dest` FOREIGN KEY (`sdest`) REFERENCES `tourdest` (`did`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tourtrip
-- ----------------------------
DROP TABLE IF EXISTS `tourtrip`;
CREATE TABLE `tourtrip` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tcover` varchar(255) NOT NULL,
  `tdescrip` varchar(255) NOT NULL,
  `tdays` tinyint(3) unsigned NOT NULL,
  `tpeople` varchar(63) NOT NULL,
  `ttrip` mediumtext NOT NULL,
  `tdest` int(10) unsigned NOT NULL,
  `tspot` int(10) unsigned NOT NULL,
  PRIMARY KEY (`tid`),
  KEY `fk_trip_dest` (`tdest`),
  KEY `fk_trip_spot` (`tspot`),
  CONSTRAINT `fk_trip_dest` FOREIGN KEY (`tdest`) REFERENCES `tourdest` (`did`),
  CONSTRAINT `fk_trip_spot` FOREIGN KEY (`tspot`) REFERENCES `tourspot` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for touruser
-- ----------------------------
DROP TABLE IF EXISTS `touruser`;
CREATE TABLE `touruser` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uname` varchar(45) NOT NULL,
  `uico` varchar(255) NOT NULL,
  `usign` varchar(31) DEFAULT NULL,
  `ulocation` varchar(63) DEFAULT NULL,
  `ujointime` varchar(15) NOT NULL,
  `utag` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET FOREIGN_KEY_CHECKS=1;
